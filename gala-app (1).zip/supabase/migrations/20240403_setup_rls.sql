-- Enable RLS for all tables function
CREATE OR REPLACE FUNCTION enable_rls_for_tables() 
RETURNS void AS $$
BEGIN
    -- Enable RLS for users table
    ALTER TABLE IF EXISTS public.users ENABLE ROW LEVEL SECURITY;
    
    -- Users table policies
    DROP POLICY IF EXISTS "Users can view their own data" ON public.users;
    CREATE POLICY "Users can view their own data" 
    ON public.users FOR SELECT 
    USING (auth.uid() = id);

    DROP POLICY IF EXISTS "Users can update their own data" ON public.users;
    CREATE POLICY "Users can update their own data" 
    ON public.users FOR UPDATE 
    USING (auth.uid() = id);

    DROP POLICY IF EXISTS "Users can insert their own data" ON public.users;
    CREATE POLICY "Users can insert their own data" 
    ON public.users FOR INSERT 
    WITH CHECK (auth.uid() = id);

    -- Enable RLS for properties table
    ALTER TABLE IF EXISTS public.properties ENABLE ROW LEVEL SECURITY;
    
    -- Properties table policies
    DROP POLICY IF EXISTS "Anyone can view published properties" ON public.properties;
    CREATE POLICY "Anyone can view published properties" 
    ON public.properties FOR SELECT 
    TO PUBLIC;

    DROP POLICY IF EXISTS "Hosts can manage their own properties" ON public.properties;
    CREATE POLICY "Hosts can manage their own properties" 
    ON public.properties FOR ALL 
    USING (auth.uid() = host_id);

    -- Enable RLS for bookings table
    ALTER TABLE IF EXISTS public.bookings ENABLE ROW LEVEL SECURITY;
    
    -- Bookings table policies
    DROP POLICY IF EXISTS "Users can view their own bookings" ON public.bookings;
    CREATE POLICY "Users can view their own bookings" 
    ON public.bookings FOR SELECT 
    USING (auth.uid() = guest_id);

    DROP POLICY IF EXISTS "Users can create their own bookings" ON public.bookings;
    CREATE POLICY "Users can create their own bookings" 
    ON public.bookings FOR INSERT 
    WITH CHECK (auth.uid() = guest_id);

    -- Enable RLS for wishlists table
    ALTER TABLE IF EXISTS public.wishlists ENABLE ROW LEVEL SECURITY;
    
    -- Wishlists table policies
    DROP POLICY IF EXISTS "Users can manage their own wishlists" ON public.wishlists;
    CREATE POLICY "Users can manage their own wishlists" 
    ON public.wishlists FOR ALL 
    USING (auth.uid() = user_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated and anon roles
GRANT EXECUTE ON FUNCTION enable_rls_for_tables TO authenticated;
GRANT EXECUTE ON FUNCTION enable_rls_for_tables TO anon;

-- Call the function to enable RLS
SELECT enable_rls_for_tables();

