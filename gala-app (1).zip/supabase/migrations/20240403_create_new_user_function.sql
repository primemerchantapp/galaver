-- Function to create a new user, bypassing RLS
CREATE OR REPLACE FUNCTION create_new_user(
  user_id UUID,
  user_email TEXT,
  user_type TEXT
) RETURNS void AS $$
BEGIN
  INSERT INTO auth.users (id, email, user_type, created_at)
  VALUES (user_id, user_email, user_type, NOW())
  ON CONFLICT (id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to the anon role
GRANT EXECUTE ON FUNCTION create_new_user TO anon;

