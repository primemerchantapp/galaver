-- Function to create users table if it doesn't exist
CREATE OR REPLACE FUNCTION create_users_table_if_not_exists()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'users') THEN
    CREATE TABLE public.users (
      id UUID PRIMARY KEY DEFAULT auth.uid(),
      email TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      profile_image TEXT,
      user_type TEXT NOT NULL CHECK (user_type IN ('traveler', 'host', 'both')),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Set up RLS (Row Level Security)
    ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
    
    -- Create policies
    CREATE POLICY "Users can view their own data" 
      ON public.users 
      FOR SELECT 
      USING (auth.uid() = id);
    
    CREATE POLICY "Users can update their own data" 
      ON public.users 
      FOR UPDATE 
      USING (auth.uid() = id);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to create properties table if it doesn't exist
CREATE OR REPLACE FUNCTION create_properties_table_if_not_exists()
RETURNS void AS $$
BEGIN
IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'properties') THEN
  CREATE TABLE public.properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    price_per_night NUMERIC NOT NULL,
    rating NUMERIC,
    reviews INTEGER,
    guests INTEGER NOT NULL,
    bedrooms INTEGER NOT NULL,
    beds INTEGER NOT NULL,
    baths INTEGER NOT NULL,
    amenities TEXT[] NOT NULL,
    images TEXT[] NOT NULL,
    host_id UUID NOT NULL,
    description TEXT NOT NULL,
    latitude NUMERIC NOT NULL,
    longitude NUMERIC NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );

  -- Set up RLS (Row Level Security)
  ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
  
  -- Create policies
  CREATE POLICY "Properties are viewable by everyone" 
    ON public.properties 
    FOR SELECT 
    TO PUBLIC;
  
  CREATE POLICY "Hosts can insert their own properties" 
    ON public.properties 
    FOR INSERT 
    WITH CHECK (auth.uid() = host_id);
  
  CREATE POLICY "Hosts can update their own properties" 
    ON public.properties 
    FOR UPDATE 
    USING (auth.uid() = host_id);
  
  CREATE POLICY "Hosts can delete their own properties" 
    ON public.properties 
    FOR DELETE 
    USING (auth.uid() = host_id);
END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to create bookings table if it doesn't exist
CREATE OR REPLACE FUNCTION create_bookings_table_if_not_exists()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'bookings') THEN
    CREATE TABLE public.bookings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      property_id UUID NOT NULL,
      guest_id UUID NOT NULL,
      check_in_date DATE NOT NULL,
      check_out_date DATE NOT NULL,
      total_price NUMERIC NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Set up RLS (Row Level Security)
    ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
    
    -- Create policies
    CREATE POLICY "Users can view their own bookings" 
      ON public.bookings 
      FOR SELECT 
      USING (auth.uid() = guest_id);
    
    CREATE POLICY "Hosts can view bookings for their properties" 
      ON public.bookings 
      FOR SELECT 
      USING (
        auth.uid() IN (
          SELECT host_id FROM public.properties WHERE id = property_id
        )
      );
    
    CREATE POLICY "Users can insert their own bookings" 
      ON public.bookings 
      FOR INSERT 
      WITH CHECK (auth.uid() = guest_id);
    
    CREATE POLICY "Users can update their own bookings" 
      ON public.bookings 
      FOR UPDATE 
      USING (auth.uid() = guest_id);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to create messages table if it doesn't exist
CREATE OR REPLACE FUNCTION create_messages_table_if_not_exists()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'messages') THEN
    CREATE TABLE public.messages (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      conversation_id UUID NOT NULL,
      sender_id UUID NOT NULL,
      receiver_id UUID NOT NULL,
      content TEXT NOT NULL,
      read BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Set up RLS (Row Level Security)
    ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
    
    -- Create policies
    CREATE POLICY "Users can view messages they sent or received" 
      ON public.messages 
      FOR SELECT 
      USING (auth.uid() = sender_id OR auth.uid() = receiver_id);
    
    CREATE POLICY "Users can insert messages they send" 
      ON public.messages 
      FOR INSERT 
      WITH CHECK (auth.uid() = sender_id);
    
    CREATE POLICY "Users can update read status of messages they received" 
      ON public.messages 
      FOR UPDATE 
      USING (auth.uid() = receiver_id);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to create wishlists table if it doesn't exist
CREATE OR REPLACE FUNCTION create_wishlists_table_if_not_exists()
RETURNS void AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'wishlists') THEN
    CREATE TABLE public.wishlists (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      property_id UUID NOT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, property_id)
    );

    -- Set up RLS (Row Level Security)
    ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;
    
    -- Create policies
    CREATE POLICY "Users can view their own wishlists" 
      ON public.wishlists 
      FOR SELECT 
      USING (auth.uid() = user_id);
    
    CREATE POLICY "Users can insert into their own wishlists" 
      ON public.wishlists 
      FOR INSERT 
      WITH CHECK (auth.uid() = user_id);
    
    CREATE POLICY "Users can delete from their own wishlists" 
      ON public.wishlists 
      FOR DELETE 
      USING (auth.uid() = user_id);
  END IF;
END;
$$ LANGUAGE plpgsql;

