"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Search, Bell, Hotel, Umbrella, Building2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import BottomNav from "@/components/bottom-nav"

export default function HomePage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="min-h-screen pb-20">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-2xl font-bold text-primary">Gala</h1>
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
          </Button>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search next Gala"
              className="pl-10 bg-muted"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </header>

      {/* Popular Destinations */}
      <section className="p-4 space-y-4">
        <h2 className="text-xl font-bold">Popular Destinations</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%20%284%29%20%286%29-XHxFuyhuJIaddBBD32fzu588DMBlvB.webp"
              alt="Siargao"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60 p-4 flex flex-col justify-end">
              <h3 className="text-white font-bold">Siargao</h3>
              <p className="text-white/90 text-sm">Surfing Paradise</p>
            </div>
          </div>
          <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%20%284%29%20%284%29-ICDd79j6UaksvAC4SaawFuwGmqSV3p.webp"
              alt="Boracay"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60 p-4 flex flex-col justify-end">
              <h3 className="text-white font-bold">Boracay</h3>
              <p className="text-white/90 text-sm">Beach Paradise</p>
            </div>
          </div>
        </div>
      </section>

      {/* Browse by Category */}
      <section className="p-4 space-y-4">
        <h2 className="text-xl font-bold">Browse by Category</h2>
        <div className="grid grid-cols-3 gap-4">
          <Button
            variant="outline"
            className="flex flex-col items-center gap-2 h-auto py-4"
            onClick={() => router.push("/listings?category=Hotels")}
          >
            <Hotel className="h-6 w-6 text-primary" />
            <span>Hotels</span>
          </Button>
          <Button
            variant="outline"
            className="flex flex-col items-center gap-2 h-auto py-4"
            onClick={() => router.push("/listings?category=Resorts")}
          >
            <Umbrella className="h-6 w-6 text-primary" />
            <span>Resorts</span>
          </Button>
          <Button
            variant="outline"
            className="flex flex-col items-center gap-2 h-auto py-4"
            onClick={() => router.push("/listings?category=Apartments")}
          >
            <Building2 className="h-6 w-6 text-primary" />
            <span>Apartments</span>
          </Button>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Available Properties (2)</h2>
          <Button variant="link" className="text-primary">
            Near Me
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <PropertyCard
            name="Lawrence Hub"
            location="Makati Avenue Pedestria..."
            price={2000}
            guests={2}
            amenities={["WiFi", "Kitchen"]}
            image="/placeholder.svg?height=300&width=400"
          />
          <PropertyCard
            name="Kiara Dee Hotel"
            location="Condo, One San Miguel A..."
            price={1500}
            guests={2}
            amenities={["WiFi", "Kitchen"]}
            image="/placeholder.svg?height=300&width=400"
          />
        </div>
      </section>

      <BottomNav />
    </div>
  )
}

interface PropertyCardProps {
  name: string
  location: string
  price: number
  guests: number
  amenities: string[]
  image: string
}

function PropertyCard({ name, location, price, guests, amenities, image }: PropertyCardProps) {
  return (
    <div className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow">
      <div className="relative aspect-[4/3]">
        <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
      </div>
      <div className="p-4 space-y-2">
        <h3 className="font-bold">{name}</h3>
        <p className="text-sm text-muted-foreground truncate">{location}</p>
        <div className="flex items-center gap-4">
          <div className="text-sm">Up to {guests} guests</div>
          <div className="flex gap-2">
            {amenities.map((amenity) => (
              <span key={amenity} className="text-xs bg-muted px-2 py-1 rounded">
                {amenity}
              </span>
            ))}
          </div>
        </div>
        <div className="font-bold">
          ₱{price.toLocaleString()} <span className="font-normal text-sm">/night</span>
        </div>
      </div>
    </div>
  )
}

