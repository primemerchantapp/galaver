"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { ArrowLeft, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import PropertyCard from "@/components/property-card"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

interface Property {
  id: string
  name: string
  location: string
  price_per_night: number
  rating: number
  images: string[]
  amenities: string[]
}

export default function SearchPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "")
  const [priceRange, setPriceRange] = useState([0, 50000])
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([])

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        let query = supabase.from("properties").select("*").order("created_at", { ascending: false })

        if (searchQuery) {
          query = query.or(`name.ilike.%${searchQuery}%,location.ilike.%${searchQuery}%`)
        }

        query = query.gte("price_per_night", priceRange[0]).lte("price_per_night", priceRange[1])

        if (selectedAmenities.length > 0) {
          query = query.contains("amenities", selectedAmenities)
        }

        const { data, error } = await query

        if (error) throw error

        setProperties(data)
      } catch (error) {
        console.error("Error fetching properties:", error)
        toast({
          title: "Error",
          description: "Failed to load properties. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProperties()
  }, [searchQuery, priceRange, selectedAmenities, toast])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
  }

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities((prev) => (prev.includes(amenity) ? prev.filter((a) => a !== amenity) : [...prev, amenity]))
  }

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <form onSubmit={handleSearch} className="flex-1 ml-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search locations"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </form>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="ml-2">
                <Filter className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
              </SheetHeader>
              <div className="py-4 space-y-4">
                <div>
                  <Label>Price Range</Label>
                  <Slider min={0} max={50000} step={1000} value={priceRange} onValueChange={setPriceRange} />
                  <div className="flex justify-between mt-2">
                    <span>₱{priceRange[0].toLocaleString()}</span>
                    <span>₱{priceRange[1].toLocaleString()}</span>
                  </div>
                </div>
                <div>
                  <Label>Amenities</Label>
                  <div className="space-y-2 mt-2">
                    {["WiFi", "Kitchen", "Free parking", "Pool", "Air conditioning"].map((amenity) => (
                      <div key={amenity} className="flex items-center">
                        <Checkbox
                          id={amenity}
                          checked={selectedAmenities.includes(amenity)}
                          onCheckedChange={() => toggleAmenity(amenity)}
                        />
                        <label
                          htmlFor={amenity}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {amenity}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Search Results */}
      <main className="container mx-auto px-4 py-6">
        <h2 className="text-xl font-bold mb-4">Search Results</h2>
        {loading ? (
          <div>Loading...</div>
        ) : properties.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {properties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          <div>No properties found</div>
        )}
      </main>
    </div>
  )
}

