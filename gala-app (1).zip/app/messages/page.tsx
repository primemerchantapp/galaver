import BottomNav from "@/components/bottom-nav"

export default function MessagesPage() {
  return (
    <div className="min-h-screen pb-[70px]">
      <h1 className="text-2xl font-bold p-4">Messages</h1>
      <p className="p-4">Your conversations with hosts and guests.</p>
      <BottomNav />
    </div>
  )
}

