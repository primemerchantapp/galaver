"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { ArrowLeft, Star, Users, Wifi, Car, Utensils, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { GoogleMap, Marker } from "@react-google-maps/api"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

interface Property {
  id: string
  name: string
  location: string
  price_per_night: number
  rating: number
  reviews: number
  guests: number
  bedrooms: number
  beds: number
  baths: number
  amenities: string[]
  images: string[]
  host_id: string
  description: string
  latitude: number
  longitude: number
}

export default function PropertyPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeImage, setActiveImage] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        // Fetch property data
        const { data, error } = await supabase.from("properties").select("*").eq("id", params.id).single()

        if (error) throw error

        setProperty(data)

        // Check if the property is in user's favorites
        if (user) {
          const { data: favoriteData, error: favoriteError } = await supabase
            .from("wishlists")
            .select()
            .eq("user_id", user.uid)
            .eq("property_id", params.id)
            .single()

          if (!favoriteError) {
            setIsFavorite(true)
          }
        }
      } catch (error) {
        console.error("Error fetching property:", error)
        toast({
          title: "Error",
          description: "Failed to load property details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProperty()
  }, [params.id, user, toast])

  const toggleFavorite = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to save properties to your wishlist.",
        variant: "destructive",
      })
      return
    }

    try {
      if (isFavorite) {
        await supabase.from("wishlists").delete().eq("user_id", user.uid).eq("property_id", params.id)
      } else {
        await supabase.from("wishlists").insert({ user_id: user.uid, property_id: params.id })
      }
      setIsFavorite(!isFavorite)
      toast({
        title: isFavorite ? "Removed from wishlist" : "Added to wishlist",
        description: isFavorite ? "Property removed from your wishlist." : "Property added to your wishlist.",
      })
    } catch (error) {
      console.error("Error updating wishlist:", error)
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  if (!property) {
    return <div className="flex items-center justify-center h-screen">Property not found</div>
  }

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold truncate flex-1 text-center">{property.name}</h1>
          <Button variant="ghost" size="icon" onClick={toggleFavorite}>
            <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
          </Button>
        </div>
      </header>

      {/* Image Gallery */}
      <div className="relative h-64 sm:h-96">
        <Image
          src={property.images[activeImage] || "/placeholder.svg"}
          alt={property.name}
          fill
          className="object-cover"
        />
        <div className="absolute bottom-4 left-4 right-4 flex justify-center">
          <div className="flex space-x-2">
            {property.images.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full ${index === activeImage ? "bg-white" : "bg-white/50"}`}
                onClick={() => setActiveImage(index)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Property Details */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">{property.name}</h1>
            <p className="text-muted-foreground">{property.location}</p>
          </div>
          <div className="flex items-center">
            <Star className="h-5 w-5 text-yellow-400 fill-current" />
            <span className="ml-1 font-semibold">{property.rating}</span>
            <span className="ml-1 text-muted-foreground">({property.reviews} reviews)</span>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-4">
          <Badge variant="secondary" className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            {property.guests} guests
          </Badge>
          <Badge variant="secondary" className="flex items-center">
            {property.bedrooms} bedrooms
          </Badge>
          <Badge variant="secondary" className="flex items-center">
            {property.beds} beds
          </Badge>
          <Badge variant="secondary" className="flex items-center">
            {property.baths} baths
          </Badge>
        </div>

        <div className="mt-6">
          <h2 className="text-xl font-bold mb-2">Description</h2>
          <p className="text-muted-foreground">{property.description}</p>
        </div>

        <div className="mt-6">
          <h2 className="text-xl font-bold mb-2">Amenities</h2>
          <div className="grid grid-cols-2 gap-4">
            {property.amenities.map((amenity) => (
              <div key={amenity} className="flex items-center">
                {amenity === "WiFi" && <Wifi className="h-5 w-5 mr-2" />}
                {amenity === "Free parking" && <Car className="h-5 w-5 mr-2" />}
                {amenity === "Kitchen" && <Utensils className="h-5 w-5 mr-2" />}
                <span>{amenity}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-6">
          <h2 className="text-xl font-bold mb-2">Location</h2>
          <div className="h-64 rounded-lg overflow-hidden">
            <GoogleMap
              mapContainerStyle={{ width: "100%", height: "100%" }}
              center={{ lat: property.latitude, lng: property.longitude }}
              zoom={14}
            >
              <Marker position={{ lat: property.latitude, lng: property.longitude }} />
            </GoogleMap>
          </div>
        </div>
      </div>

      {/* Booking CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div>
            <span className="text-2xl font-bold">₱{property.price_per_night.toLocaleString()}</span>
            <span className="text-muted-foreground"> / night</span>
          </div>
          <Button onClick={() => router.push(`/booking/${params.id}`)}>Book Now</Button>
        </div>
      </div>
    </div>
  )
}

