"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { DateRangePicker } from "@/components/ui/date-range-picker"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

interface Property {
  id: string
  name: string
  price_per_night: number
  guests: number
}

export default function BookingPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | null>(null)
  const [guestCount, setGuestCount] = useState(1)
  const [totalPrice, setTotalPrice] = useState(0)

  useEffect(() => {
    if (!user) {
      router.push("/auth")
    }
  }, [user, router])

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        const { data, error } = await supabase
          .from("properties")
          .select("id, name, price_per_night, guests")
          .eq("id", params.id)
          .single()

        if (error) throw error

        setProperty(data)
      } catch (error) {
        console.error("Error fetching property:", error)
        toast({
          title: "Error",
          description: "Failed to load property details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProperty()
  }, [params.id, toast])

  useEffect(() => {
    if (property && dateRange) {
      const nights = Math.ceil((dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 3600 * 24))
      setTotalPrice(property.price_per_night * nights)
    }
  }, [property, dateRange])

  const handleBooking = async () => {
    if (!user || !property || !dateRange) return

    try {
      const { data, error } = await supabase.from("bookings").insert({
        property_id: property.id,
        guest_id: user.uid,
        check_in_date: dateRange.from.toISOString(),
        check_out_date: dateRange.to.toISOString(),
        total_price: totalPrice,
        guests: guestCount,
        status: "pending",
      })

      if (error) throw error

      toast({
        title: "Booking Successful",
        description: "Your booking has been confirmed. Check your email for details.",
      })

      router.push("/bookings")
    } catch (error) {
      console.error("Error creating booking:", error)
      toast({
        title: "Booking Failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  if (!property) {
    return <div className="flex items-center justify-center h-screen">Property not found</div>
  }

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold ml-2">Book {property.name}</h1>
        </div>
      </header>

      {/* Booking Form */}
      <div className="container mx-auto px-4 py-6">
        <div className="space-y-6">
          <div>
            <Label htmlFor="dates">Dates</Label>
            <DateRangePicker id="dates" selected={dateRange} onSelect={setDateRange} className="w-full" />
          </div>

          <div>
            <Label htmlFor="guests">Guests</Label>
            <Select value={guestCount.toString()} onValueChange={(value) => setGuestCount(Number(value))}>
              <SelectTrigger id="guests">
                <SelectValue placeholder="Select number of guests" />
              </SelectTrigger>
              <SelectContent>
                {[...Array(property.guests)].map((_, i) => (
                  <SelectItem key={i} value={(i + 1).toString()}>
                    {i + 1} {i === 0 ? "guest" : "guests"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="payment">Payment Method</Label>
            <Select>
              <SelectTrigger id="payment">
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="credit_card">Credit Card</SelectItem>
                <SelectItem value="paypal">PayPal</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <h2 className="text-xl font-bold mb-2">Price Details</h2>
            <div className="flex justify-between">
              <span>
                ₱{property.price_per_night.toLocaleString()} x{" "}
                {dateRange ? Math.ceil((dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 3600 * 24)) : 0}{" "}
                nights
              </span>
              <span>₱{totalPrice.toLocaleString()}</span>
            </div>
            <div className="flex justify-between font-bold mt-2">
              <span>Total</span>
              <span>₱{totalPrice.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Booking CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
        <div className="container mx-auto">
          <Button onClick={handleBooking} className="w-full">
            Confirm Booking
          </Button>
        </div>
      </div>
    </div>
  )
}

