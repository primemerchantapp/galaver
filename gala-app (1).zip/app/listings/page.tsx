"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@supabase/supabase-js"
import { useRouter } from "next/navigation"
import { Menu, Search, User, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import PropertyCard from "@/components/property-card"
import CategoryTabs from "@/components/category-tabs"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/components/auth-provider"
import SidebarNav from "@/components/sidebar-nav"
import { useToast } from "@/components/ui/use-toast"
import { initializeDatabase } from "@/lib/db-init"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Property type definition
type Property = {
  id: string
  name: string
  location: string
  price_per_night: number
  category: string
  max_guests: number
  amenities: string[]
  images: string[]
  created_at: string
}

export default function ListingsPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [dbInitialized, setDbInitialized] = useState(false)
  const [dbInitError, setDbInitError] = useState<string | null>(null)
  const [isNearMeActive, setIsNearMeActive] = useState(false)
  const [favorites, setFavorites] = useState<string[]>([])

  // Categories
  const categories = [
    "All",
    "Hotels",
    "Resorts",
    "Condominiums",
    "Apartments",
    "Town Houses",
    "Recreations",
    "Adventures",
    "Others",
  ]

  // Initialize database tables if they don't exist
  useEffect(() => {
    const setupDatabase = async () => {
      try {
        await initializeDatabase(supabase)
        setDbInitialized(true)
      } catch (error) {
        console.error("Error initializing database:", error)
        setDbInitError("Could not initialize database. Using sample data instead.")
        setLoading(false)
        setDbInitialized(true) // Set to true to prevent further initialization attempts
      }
    }

    setupDatabase()
  }, [])

  // Fetch properties after database is initialized
  useEffect(() => {
    if (dbInitialized) {
      fetchProperties()
    }
  }, [dbInitialized])

  // Function to fetch properties from Supabase
  const fetchProperties = async () => {
    try {
      setLoading(true)

      let query = supabase
        .from("properties")
        .select("*")
        .order("created_at", { ascending: false })
        .range((page - 1) * 10, page * 10 - 1)

      // Apply category filter if not "All"
      if (selectedCategory !== "All") {
        query = query.eq("category", selectedCategory)
      }

      const { data, error } = await query

      if (error) {
        console.error("Error fetching properties:", error)
        setHasMore(false)
        return
      }

      if (data.length < 10) {
        setHasMore(false)
      }

      if (page === 1) {
        setProperties(data as Property[])
      } else {
        setProperties((prev) => [...prev, ...(data as Property[])])
      }
    } catch (error) {
      console.error("Error fetching properties:", error)
      setHasMore(false)
    } finally {
      setLoading(false)
    }
  }

  // Handle category change
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
    setPage(1)
    setHasMore(true)
  }

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Filter properties based on search query
    if (searchQuery.trim()) {
      const filtered = properties.filter(
        (property) =>
          property.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          property.location.toLowerCase().includes(searchQuery.toLowerCase()),
      )
      setProperties(filtered)
    } else {
      fetchProperties()
    }
  }

  // Load more properties
  const loadMore = () => {
    if (!loading && hasMore) {
      setPage((prev) => prev + 1)
    }
  }

  // Toggle favorite
  const toggleFavorite = async (propertyId: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to save properties to your wishlist.",
        variant: "destructive",
      })
      return
    }

    try {
      if (favorites.includes(propertyId)) {
        await supabase.from("wishlists").delete().eq("user_id", user.uid).eq("property_id", propertyId)
        setFavorites(favorites.filter((id) => id !== propertyId))
      } else {
        await supabase.from("wishlists").insert({ user_id: user.uid, property_id: propertyId })
        setFavorites([...favorites, propertyId])
      }
    } catch (error) {
      console.error("Error updating wishlist:", error)
      toast({
        title: "Error",
        description: "Failed to update wishlist. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="mr-2">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <SidebarNav />
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-bold text-primary gala-heading">GALA</h1>
          </div>

          <form onSubmit={handleSearch} className="flex-1 max-w-md mx-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search next Gala"
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </form>

          <Button variant="ghost" size="icon" onClick={() => (user ? router.push("/profile") : router.push("/auth"))}>
            <User className="h-5 w-5" />
          </Button>
        </div>

        {/* Category Tabs */}
        <CategoryTabs
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={handleCategoryChange}
        />
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {dbInitError && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
            <p className="font-bold">Warning</p>
            <p>{dbInitError}</p>
          </div>
        )}
        {loading && page === 1 ? (
          <div className="text-center py-10">Loading properties...</div>
        ) : properties.length > 0 ? (
          <>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Available Properties ({properties.length})</h2>
              <Button
                variant={isNearMeActive ? "default" : "outline"}
                onClick={() => setIsNearMeActive(!isNearMeActive)}
                className="text-xs px-2 py-1 h-auto"
              >
                <MapPin className="h-3 w-3 mr-1" />
                Near Me
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {properties.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  onToggleFavorite={toggleFavorite}
                  isFavorite={favorites.includes(property.id)}
                  mainImage={property.images[0]}
                />
              ))}
            </div>

            {hasMore && (
              <div className="text-center mt-8">
                <Button onClick={loadMore} disabled={loading} variant="outline">
                  {loading ? "Loading..." : "Load More"}
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-10">No properties found in this category.</div>
        )}
      </main>
    </div>
  )
}

