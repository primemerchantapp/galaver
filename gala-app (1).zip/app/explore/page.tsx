import BottomNav from "@/components/bottom-nav"

export default function ExplorePage() {
  return (
    <div className="min-h-screen pb-[70px]">
      <h1 className="text-2xl font-bold p-4">Explore</h1>
      <p className="p-4">Explore new and exciting destinations.</p>
      <BottomNav />
    </div>
  )
}

