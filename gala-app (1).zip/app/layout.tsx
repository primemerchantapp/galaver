import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Toaster } from "@/components/ui/toaster"
import { AuthProvider } from "@/components/auth-provider"
import { createClient } from "@supabase/supabase-js"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Gala - Discover Unique Stays in the Philippines",
  description: "Find and book unique accommodations across the Philippines",
    generator: 'v0.dev'
}

// Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("Missing Supabase environment variables")
}

const supabase = createClient(supabaseUrl!, supabaseAnonKey!)

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  try {
    // Enable RLS for all tables
    await supabase.rpc("enable_rls_for_tables")

    // Sign in anonymously
    const { data, error } = await supabase.auth.signInAnonymously()

    if (error) {
      console.error("Error signing in anonymously:", error.message)
    } else if (data.user) {
      console.log("Anonymous user signed in:", data.user.id)

      try {
        // Insert user directly into the users table
        const { error: insertError } = await supabase
          .from("users")
          .insert({
            id: data.user.id,
            user_type: "guest",
            created_at: new Date().toISOString(),
          })
          .select()
          .single()

        if (insertError) {
          // If insert fails, user might already exist
          console.log("User might already exist:", insertError.message)
        } else {
          console.log("User created successfully")
        }
      } catch (dbError) {
        console.error("Database error:", dbError)
      }
    }
  } catch (error) {
    console.error("Error in RootLayout:", error)
  }

  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  )
}



import './globals.css'