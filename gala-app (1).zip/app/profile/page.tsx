"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { createClient } from "@supabase/supabase-js"
import { ArrowLeft, User, Mail, Phone, Edit, Home, Heart, MessageSquare, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"
import BottomNav from "@/components/bottom-nav"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// User profile type
type UserProfile = {
  id: string
  name: string
  email: string
  phone?: string
  profile_image?: string
  user_type: string
  created_at: string
}

export default function ProfilePage() {
  const router = useRouter()
  const { user, signOut } = useAuth()
  const { toast } = useToast()

  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  // Redirect if not logged in
  useEffect(() => {
    if (!user && !loading) {
      router.push("/auth")
    }
  }, [user, loading, router])

  // Fetch user profile
  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) return

      try {
        setLoading(true)

        const { data, error } = await supabase.from("users").select("*").eq("id", user.uid).single()

        if (error) throw error

        setProfile(data as UserProfile)
      } catch (error) {
        console.error("Error fetching profile:", error)
        toast({
          title: "Error",
          description: "Failed to load profile data",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [user, toast])

  // Handle sign out
  const handleSignOut = async () => {
    try {
      await signOut()
      router.push("/auth")
    } catch (error) {
      console.error("Error signing out:", error)
      toast({
        title: "Error",
        description: "Failed to sign out",
        variant: "destructive",
      })
    }
  }

  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading profile...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen pb-[70px]">
      <h1 className="text-2xl font-bold p-4">Profile</h1>
      <p className="p-4">Manage your account and settings.</p>
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold ml-2 gala-heading">Profile</h1>
        </div>
      </header>

      {/* Profile Content */}
      <div className="container mx-auto px-4 py-6">
        {/* Profile Overview */}
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center text-white text-3xl">
            {profile?.profile_image ? (
              <Image
                src={profile.profile_image || "/placeholder.svg"}
                alt={profile.name}
                width={96}
                height={96}
                className="rounded-full object-cover"
              />
            ) : (
              profile?.name?.[0] || user.email?.[0] || "U"
            )}
          </div>

          <h2 className="mt-4 text-xl font-bold">{profile?.name || "User"}</h2>
          <p className="text-sm text-muted-foreground">{profile?.user_type || "Traveler"}</p>

          <Button variant="outline" size="sm" className="mt-4" onClick={() => router.push("/profile/edit")}>
            <Edit className="h-4 w-4 mr-2" />
            Edit Profile
          </Button>
        </div>

        <Separator className="my-6" />

        {/* Contact Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold gala-heading">Contact Information</h3>

          <div className="flex items-center">
            <User className="h-5 w-5 mr-3 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Name</p>
              <p>{profile?.name || "Not set"}</p>
            </div>
          </div>

          <div className="flex items-center">
            <Mail className="h-5 w-5 mr-3 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Email</p>
              <p>{profile?.email || user.email || "Not set"}</p>
            </div>
          </div>

          <div className="flex items-center">
            <Phone className="h-5 w-5 mr-3 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Phone</p>
              <p>{profile?.phone || "Not set"}</p>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Quick Links */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold gala-heading">Quick Links</h3>

          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="justify-start" onClick={() => router.push("/bookings")}>
              <Home className="h-5 w-5 mr-2" />
              My Bookings
            </Button>

            <Button variant="outline" className="justify-start" onClick={() => router.push("/wishlists")}>
              <Heart className="h-5 w-5 mr-2" />
              My Wishlists
            </Button>

            <Button variant="outline" className="justify-start" onClick={() => router.push("/messages")}>
              <MessageSquare className="h-5 w-5 mr-2" />
              Messages
            </Button>

            {(profile?.user_type === "host" || profile?.user_type === "both") && (
              <Button variant="outline" className="justify-start" onClick={() => router.push("/host/listings")}>
                <Home className="h-5 w-5 mr-2" />
                My Listings
              </Button>
            )}
          </div>
        </div>

        <Separator className="my-6" />

        {/* Sign Out */}
        <Button variant="destructive" className="w-full" onClick={handleSignOut}>
          <LogOut className="h-5 w-5 mr-2" />
          Sign Out
        </Button>
      </div>
      <BottomNav />
    </div>
  )
}

