"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Mail, X, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AccountLinking } from "@/components/account-linking"

export default function AuthPage() {
  const router = useRouter()
  const { signIn, signUp, signInWithGoogle, signInAnonymously } = useAuth()
  const { toast } = useToast()
  const [phoneNumber, setPhoneNumber] = useState("")
  const [countryCode, setCountryCode] = useState("+63")
  const [isLoading, setIsLoading] = useState(false)
  const [showLinking, setShowLinking] = useState(false)

  const handleContinue = async () => {
    if (!phoneNumber) {
      toast({
        title: "Error",
        description: "Please enter your phone number",
        variant: "destructive",
      })
      return
    }

    // Phone auth will be implemented later
    toast({
      title: "Coming Soon",
      description: "Phone authentication will be available soon!",
    })
  }

  const handleGuestLogin = async () => {
    try {
      setIsLoading(true)
      await signInAnonymously()
      router.push("/")
    } catch (error) {
      console.error("Guest login error:", error)
      toast({
        title: "Error",
        description: "Failed to continue as guest. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen p-4">
      <Button variant="ghost" size="icon" className="mb-4" onClick={() => router.back()}>
        <X className="h-6 w-6" />
      </Button>

      <h1 className="text-2xl font-bold mb-8">Log in or sign up with Gala</h1>

      {!showLinking ? (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Country/Region</label>
            <Select value={countryCode} onValueChange={setCountryCode}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="+63">Philippines (+63)</SelectItem>
                {/* Add more countries later */}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Phone number</label>
            <Input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="text-lg"
              placeholder="905 674 1316"
            />
          </div>

          <p className="text-sm text-muted-foreground">
            We'll call or text you to confirm your number. Standard message and data rates apply.
          </p>

          <Button className="w-full bg-primary" onClick={handleContinue} disabled={isLoading}>
            Continue
          </Button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">or</span>
            </div>
          </div>

          <Button variant="outline" className="w-full justify-start" onClick={() => router.push("/auth/email")}>
            <Mail className="mr-2 h-5 w-5" />
            Continue with Email
          </Button>

          <Button variant="outline" className="w-full justify-start" onClick={() => signInWithGoogle()}>
            <img src="/google-logo.png" alt="Google" className="mr-2 h-5 w-5" />
            Continue with Google
          </Button>

          <Button variant="outline" className="w-full justify-start" onClick={handleGuestLogin} disabled={isLoading}>
            <User className="mr-2 h-5 w-5" />
            Continue as Guest
          </Button>

          <Button variant="link" className="w-full" onClick={() => setShowLinking(true)}>
            Link Existing Account
          </Button>
        </div>
      ) : (
        <div>
          <h2 className="text-xl font-semibold mb-4">Link Existing Account</h2>
          <AccountLinking />
          <Button variant="link" className="mt-4" onClick={() => setShowLinking(false)}>
            Back to Login Options
          </Button>
        </div>
      )}
    </div>
  )
}

