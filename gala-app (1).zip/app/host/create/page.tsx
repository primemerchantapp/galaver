"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { ArrowLeft, Upload, X, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { initializeDatabase } from "@/lib/db-init"

// Supabase client
const supabaseUrl = "https://myrdregezfvnnowgizws.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cmRyZWdlemZ2bm5vd2dpendzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA5MzAzNTQsImV4cCI6MjA1NjUwNjM1NH0.5otaiGdbB47qI1GPv23s3DBrtW0gAUGgDhu9tSmxQ1A"
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Categories and amenities
const categories = [
  "Hotels",
  "Resorts",
  "Condominiums",
  "Apartments",
  "Town Houses",
  "Recreations",
  "Adventures",
  "Others",
]

const amenitiesList = [
  "WiFi",
  "Parking",
  "Kitchen",
  "Air Conditioning",
  "Pool",
  "TV",
  "Washing Machine",
  "Balcony",
  "Gym",
]

export default function CreatePropertyPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [dbInitialized, setDbInitialized] = useState(false)

  // Form state
  const [name, setName] = useState("")
  const [category, setCategory] = useState("")
  const [location, setLocation] = useState("")
  const [price, setPrice] = useState("")
  const [maxGuests, setMaxGuests] = useState("")
  const [description, setDescription] = useState("")
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([])
  const [images, setImages] = useState<File[]>([])
  const [video, setVideo] = useState<File | null>(null)
  const [imageUrls, setImageUrls] = useState<string[]>([])
  const [videoUrl, setVideoUrl] = useState<string>("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Initialize database
  useEffect(() => {
    const setupDatabase = async () => {
      try {
        await initializeDatabase(supabase)
        setDbInitialized(true)
      } catch (error) {
        console.error("Error initializing database:", error)
        toast({
          title: "Database Error",
          description: "Could not initialize database. Some features may not work correctly.",
          variant: "destructive",
        })
      }
    }

    setupDatabase()
  }, [toast])

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      router.push("/auth")
    }
  }, [user, router])

  if (!user) {
    return null
  }

  // Handle amenity toggle
  const toggleAmenity = (amenity: string) => {
    if (selectedAmenities.includes(amenity)) {
      setSelectedAmenities(selectedAmenities.filter((a) => a !== amenity))
    } else {
      setSelectedAmenities([...selectedAmenities, amenity])
    }
  }

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // Limit to 5 images
    if (images.length + files.length > 5) {
      toast({
        title: "Too many images",
        description: "You can upload a maximum of 5 images",
        variant: "destructive",
      })
      return
    }

    // Create preview URLs
    const newImages = Array.from(files)
    const newImageUrls = newImages.map((file) => URL.createObjectURL(file))

    setImages([...images, ...newImages])
    setImageUrls([...imageUrls, ...newImageUrls])
  }

  // Handle video upload
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    const file = files[0]

    // Check file size (max 30MB)
    if (file.size > 30 * 1024 * 1024) {
      toast({
        title: "Video too large",
        description: "Video must be less than 30MB",
        variant: "destructive",
      })
      return
    }

    setVideo(file)
    setVideoUrl(URL.createObjectURL(file))
  }

  // Remove image
  const removeImage = (index: number) => {
    const newImages = [...images]
    const newImageUrls = [...imageUrls]

    newImages.splice(index, 1)
    newImageUrls.splice(index, 1)

    setImages(newImages)
    setImageUrls(newImageUrls)
  }

  // Remove video
  const removeVideo = () => {
    setVideo(null)
    setVideoUrl("")
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to create a listing",
        variant: "destructive",
      })
      router.push("/auth")
      return
    }

    // Validate form
    if (!name || !category || !location || !price || !maxGuests || !description) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    if (images.length === 0) {
      toast({
        title: "Images required",
        description: "Please upload at least one image",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Check if database is initialized
      if (!dbInitialized) {
        await initializeDatabase(supabase)
      }

      // Upload images to Supabase Storage
      const uploadedImageUrls = []

      for (const image of images) {
        const fileName = `${user.uid}/${Date.now()}-${image.name}`
        const { data, error } = await supabase.storage.from("property-images").upload(fileName, image)

        if (error) throw error

        const { data: urlData } = supabase.storage.from("property-images").getPublicUrl(fileName)

        uploadedImageUrls.push(urlData.publicUrl)
      }

      // Upload video if exists
      let uploadedVideoUrl = ""

      if (video) {
        const fileName = `${user.uid}/${Date.now()}-${video.name}`
        const { data, error } = await supabase.storage.from("property-videos").upload(fileName, video)

        if (error) throw error

        const { data: urlData } = supabase.storage.from("property-videos").getPublicUrl(fileName)

        uploadedVideoUrl = urlData.publicUrl
      }

      // Create property listing in Supabase
      const { data, error } = await supabase.from("properties").insert({
        name,
        category,
        location,
        price_per_night: Number.parseFloat(price),
        max_guests: Number.parseInt(maxGuests),
        description,
        amenities: selectedAmenities,
        images: uploadedImageUrls,
        video_url: uploadedVideoUrl,
        host_id: user.uid,
        created_at: new Date().toISOString(),
      })

      if (error) throw error

      toast({
        title: "Success!",
        description: "Your property has been listed successfully",
      })

      // Redirect to listings page
      router.push("/listings")
    } catch (error) {
      console.error("Error creating property:", error)
      toast({
        title: "Error",
        description: "Failed to create property listing. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen pb-16">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container mx-auto px-4 py-3 flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold ml-2 gala-heading">Host a Property</h1>
        </div>
      </header>

      {/* Form */}
      <div className="container mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Details */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold gala-heading">Basic Details</h2>

            <div className="space-y-2">
              <Label htmlFor="name">Property Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Cozy Beachfront Villa"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Makati Avenue, Makati, Metro Manila"
                required
              />
            </div>
          </div>

          {/* Pricing & Capacity */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold gala-heading">Pricing & Capacity</h2>

            <div className="space-y-2">
              <Label htmlFor="price">Price per Night (PHP)</Label>
              <Input
                id="price"
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="e.g. 5000"
                min="1"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxGuests">Maximum Guests</Label>
              <Input
                id="maxGuests"
                type="number"
                value={maxGuests}
                onChange={(e) => setMaxGuests(e.target.value)}
                placeholder="e.g. 4"
                min="1"
                required
              />
            </div>
          </div>

          {/* Amenities */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold gala-heading">Amenities</h2>

            <div className="grid grid-cols-2 gap-4">
              {amenitiesList.map((amenity) => (
                <div key={amenity} className="flex items-center space-x-2">
                  <Checkbox
                    id={`amenity-${amenity}`}
                    checked={selectedAmenities.includes(amenity)}
                    onCheckedChange={() => toggleAmenity(amenity)}
                  />
                  <Label htmlFor={`amenity-${amenity}`}>{amenity}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Media Upload */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold gala-heading">Media Upload</h2>

            <div className="space-y-2">
              <Label>Images (Max 5)</Label>
              <div className="grid grid-cols-3 gap-2">
                {imageUrls.map((url, index) => (
                  <div key={index} className="relative aspect-square rounded-md overflow-hidden border">
                    <img
                      src={url || "/placeholder.svg"}
                      alt={`Preview ${index}`}
                      className="w-full h-full object-cover"
                    />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => removeImage(index)}
                      type="button"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                {images.length < 5 && (
                  <label className="flex flex-col items-center justify-center border border-dashed rounded-md aspect-square cursor-pointer hover:bg-muted/50">
                    <Plus className="h-6 w-6 mb-2" />
                    <span className="text-xs text-center">Add Image</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageUpload}
                      multiple={images.length < 4}
                    />
                  </label>
                )}
              </div>
              <p className="text-xs text-muted-foreground">Upload up to 5 images of your property</p>
            </div>

            <div className="space-y-2">
              <Label>Video (Optional)</Label>
              {videoUrl ? (
                <div className="relative rounded-md overflow-hidden border">
                  <video src={videoUrl} className="w-full h-auto" controls />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2 h-6 w-6"
                    onClick={removeVideo}
                    type="button"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center border border-dashed rounded-md p-6 cursor-pointer hover:bg-muted/50">
                  <Upload className="h-8 w-8 mb-2" />
                  <span>Upload a video</span>
                  <span className="text-xs text-muted-foreground">Max 30 seconds, portrait mode</span>
                  <input type="file" accept="video/*" className="hidden" onChange={handleVideoUpload} />
                </label>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold gala-heading">Description</h2>

            <div className="space-y-2">
              <Label htmlFor="description">Property Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your property, house rules, and other relevant information..."
                rows={6}
                required
              />
            </div>
          </div>

          {/* Submit Button */}
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Creating Listing..." : "Publish Property"}
          </Button>
        </form>
      </div>
    </div>
  )
}

