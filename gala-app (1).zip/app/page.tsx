"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { Plus, Bell, Search, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import CategoryTabs from "@/components/category-tabs"
import PropertyCard from "@/components/property-card"
import BottomNav from "@/components/bottom-nav"

// Sample properties data
const sampleProperties = [
  // HOTELS
  {
    id: "1",
    name: "The Peninsula Manila",
    location: "Makati, Metro Manila",
    price_per_night: 15000,
    guests: 2,
    amenities: ["WiFi", "Lounge Access", "Room Service", "Spa", "Gym"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2841%29-6e37Ci0HdwrtuIrL8ly4iPOKkQJpa3.jpeg", // Main image - Lounge
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg",
    ],
    category: "Hotels",
    description: "Luxury 5-star hotel with exclusive lounge access and premium amenities",
    owner: "Peninsula Hotels Group",
    coordinates: { lat: 14.5549, lng: 121.0244 },
  },
  {
    id: "2",
    name: "Shangri-La BGC",
    location: "Bonifacio Global City, Metro Manila",
    price_per_night: 18000,
    guests: 2,
    amenities: ["City View", "Executive Lounge", "Work Space", "Pool", "Gym"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg", // Main image - Executive Suite
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2841%29-6e37Ci0HdwrtuIrL8ly4iPOKkQJpa3.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg",
    ],
    category: "Hotels",
    description: "Executive suite with panoramic city views and premium business amenities",
    owner: "Shangri-La Hotels",
    coordinates: { lat: 14.5535, lng: 121.046 },
  },
  {
    id: "3",
    name: "Hilton Manila",
    location: "Newport City, Pasay",
    price_per_night: 12000,
    guests: 4,
    amenities: ["Twin Beds", "Pool Access", "Airport Shuttle", "Gym", "Restaurant"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg", // Main image - Twin Room
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2841%29-6e37Ci0HdwrtuIrL8ly4iPOKkQJpa3.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg",
    ],
    category: "Hotels",
    description: "Modern twin room with contemporary design and airport convenience",
    owner: "Hilton Hotels",
    coordinates: { lat: 14.5235, lng: 121.0164 },
  },

  // RESORTS
  {
    id: "4",
    name: "Mactan Seaside Resort",
    location: "Mactan Island, Cebu",
    price_per_night: 25000,
    guests: 4,
    amenities: ["Beachfront", "Infinity Pool", "Spa", "Water Sports", "Restaurants"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2840%29-mxL2eLhk6lhzgVI0f8QdvQ7hfeyWQS.jpeg", // Main image - Resort Exterior
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
    ],
    category: "Resorts",
    description: "Luxury beachfront resort with stunning infinity pools and ocean views",
    owner: "Mactan Luxury Resorts",
    coordinates: { lat: 10.3157, lng: 123.9789 },
  },
  {
    id: "5",
    name: "Baguio Heritage Resort",
    location: "Baguio City",
    price_per_night: 15000,
    guests: 3,
    amenities: ["Mountain View", "Restaurant", "Spa", "Garden", "Room Service"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/expediav2-601348-adb170-787981.jpg-cLXfGf0jaSonc0x9JUALRMrKKco1lU.jpeg", // Main image - Heritage Building
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2841%29-6e37Ci0HdwrtuIrL8ly4iPOKkQJpa3.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
    ],
    category: "Resorts",
    description: "Colonial-inspired mountain resort with traditional charm",
    owner: "Heritage Resorts PH",
    coordinates: { lat: 16.4023, lng: 120.596 },
  },
  {
    id: "6",
    name: "Palawan Wellness Resort",
    location: "El Nido, Palawan",
    price_per_night: 20000,
    guests: 2,
    amenities: ["Spa", "Yoga Studio", "Organic Restaurant", "Private Beach", "Meditation Garden"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top10hotelspas-theretreatspa-1572490634.jpg-BaJAYKqLpP6ueIk7CFYls1RPranHI6.jpeg", // Main image - Spa
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%2840%29-mxL2eLhk6lhzgVI0f8QdvQ7hfeyWQS.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/expediav2-601348-adb170-787981.jpg-cLXfGf0jaSonc0x9JUALRMrKKco1lU.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
    ],
    category: "Resorts",
    description: "Wellness resort featuring luxury spa treatments and holistic experiences",
    owner: "Palawan Eco Resorts",
    coordinates: { lat: 11.1956, lng: 119.415 },
  },

  // APARTMENTS/CONDOS
  {
    id: "7",
    name: "BGC Luxury Apartment",
    location: "Bonifacio Global City, Metro Manila",
    price_per_night: 8500,
    guests: 4,
    amenities: ["Full Kitchen", "City View", "WiFi", "Pool", "Gym"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image2.png.png-UDPxsre21tgl2Vfk5IifkPYisihzbe.webp", // Main image - Modern Apartment
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Two-bedroom-Suite-2-scaled-Wz1Dt5wIpuA2HlpTycxvEGTVKdDuq5.webp",
    ],
    category: "Apartments",
    description: "Modern apartment with panoramic city views and full amenities",
    owner: "BGC Residences",
    coordinates: { lat: 14.5535, lng: 121.046 },
  },
  {
    id: "8",
    name: "Heritage Suite Makati",
    location: "Makati, Metro Manila",
    price_per_night: 12000,
    guests: 2,
    amenities: ["Vintage Design", "Kitchenette", "Work Space", "Pool", "Concierge"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/JUNIOR-SUITE_209_-Bedroom-scaled.jpg-s6osn6BO1AG7DIk9C98rYRmlbvvVRf.jpeg", // Main image - Heritage Suite
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image2.png.png-UDPxsre21tgl2Vfk5IifkPYisihzbe.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
    ],
    category: "Apartments",
    description: "Luxury suite featuring vintage design elements and modern comforts",
    owner: "Makati Heritage Properties",
    coordinates: { lat: 14.5547, lng: 121.0244 },
  },
  {
    id: "9",
    name: "Ortigas Twin Suite",
    location: "Ortigas Center, Pasig",
    price_per_night: 6500,
    guests: 4,
    amenities: ["Twin Beds", "City View", "WiFi", "Pool", "Gym"],
    images: [
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Two-bedroom-Suite-2-scaled-Wz1Dt5wIpuA2HlpTycxvEGTVKdDuq5.webp", // Main image - Twin Suite
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image2.png.png-UDPxsre21tgl2Vfk5IifkPYisihzbe.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/holiday-inn-quanzhou-9447283299-4x3-NoqtdZ8XxUaNHU05GJBEqZOQ2eCkaZ.webp",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1407953244000-177513283.jpg-xyKHmVGW20pp5cNmUYYYIqyGKsJqse.jpeg",
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287596189.jpg-GL6mWUKuPEz2Nv2SQFjYpiQVwXreQM.jpeg",
    ],
    category: "Condominiums",
    description: "Contemporary twin suite perfect for families or group travelers",
    owner: "Ortigas Luxury Rentals",
    coordinates: { lat: 14.5848, lng: 121.0614 },
  },
]

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  // Remove this line
  // const [properties, setProperties] = useState(sampleProperties)
  const [filteredProperties, setFilteredProperties] = useState(sampleProperties)
  const [loading, setLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [page, setPage] = useState(1)
  const [searchQuery, setSearchQuery] = useState("")
  const [isNearMeActive, setIsNearMeActive] = useState(false)
  const [favorites, setFavorites] = useState<string[]>([])
  const observer = useRef<IntersectionObserver>()

  // Calculate distance between two points using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371 // Radius of the Earth in km
    const dLat = (lat2 - lat1) * (Math.PI / 180)
    const dLon = (lon2 - lon1) * (Math.PI / 180)
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  // Last element ref for infinite scrolling
  const lastPropertyElementRef = useCallback(
    (node: HTMLDivElement | null) => {
      if (loading) return
      if (observer.current) observer.current.disconnect()
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          setPage((prevPage) => prevPage + 1)
        }
      })
      if (node) observer.current.observe(node)
    },
    [loading, hasMore],
  )

  // Load more properties
  useEffect(() => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setFilteredProperties((prev) => [...prev, ...sampleProperties])
      setHasMore(page < 3) // Limit to 3 pages for demo
      setLoading(false)
    }, 500)
  }, [page])

  // Filter properties based on category and search query
  useEffect(() => {
    let result = sampleProperties
    if (selectedCategory !== "All") {
      result = result.filter((property) => property.category === selectedCategory)
    }
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (property) =>
          property.name.toLowerCase().includes(query) ||
          property.location.toLowerCase().includes(query) ||
          property.description.toLowerCase().includes(query) ||
          property.owner.toLowerCase().includes(query),
      )
    }
    setFilteredProperties(result)
  }, [selectedCategory, searchQuery])

  // Sort properties by distance from user
  const sortPropertiesByDistance = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLat = position.coords.latitude
          const userLng = position.coords.longitude

          const sortedProperties = [...filteredProperties]
            .map((property) => {
              const distance = calculateDistance(userLat, userLng, property.coordinates.lat, property.coordinates.lng)
              return { ...property, distance }
            })
            .sort((a, b) => (a.distance || 0) - (b.distance || 0))

          setFilteredProperties(sortedProperties)
          setIsNearMeActive(true)
        },
        (error) => {
          console.error("Error getting user location:", error)
          alert("Unable to get your location. Please check your browser settings and try again.")
        },
      )
    } else {
      alert("Geolocation is not supported by this browser.")
    }
  }

  const toggleFavorite = (propertyId: string) => {
    setFavorites((prevFavorites) => {
      if (prevFavorites.includes(propertyId)) {
        return prevFavorites.filter((id) => id !== propertyId)
      } else {
        return [...prevFavorites, propertyId]
      }
    })
  }

  return (
    <div className="min-h-screen pb-[70px]">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" size="icon">
            <Plus className="h-6 w-6" />
          </Button>
          <h1 className="text-2xl font-bold text-primary">Gala</h1>
          <Button variant="ghost" size="icon">
            <Bell className="h-6 w-6" />
          </Button>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search next Gala"
              className="pl-10 bg-muted/50 border-0"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Category Tabs */}
        <CategoryTabs selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
      </header>

      {/* Property Listings */}
      <main className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Available Properties ({filteredProperties.length})</h2>
          <Button
            variant={isNearMeActive ? "default" : "outline"}
            onClick={sortPropertiesByDistance}
            className="text-xs px-2 py-1 h-auto"
          >
            <MapPin className="h-3 w-3 mr-1" />
            Near Me
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {filteredProperties.map((property, index) => {
            return (
              <PropertyCard
                key={property.id}
                property={property}
                onToggleFavorite={toggleFavorite}
                isFavorite={favorites.includes(property.id)}
                mainImage={property.images[0]}
              />
            )
          })}
        </div>
        {loading && <div className="text-center py-4 text-muted-foreground text-sm">Loading more properties...</div>}
      </main>

      <BottomNav />
    </div>
  )
}

