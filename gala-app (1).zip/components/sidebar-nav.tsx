"use client"

import { useRouter } from "next/navigation"
import { Home, PlusCircle, User, LogOut, Heart, MessageSquare } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"

export default function SidebarNav() {
  const router = useRouter()
  const { user, signOut } = useAuth()

  const handleSignOut = async () => {
    try {
      await signOut()
      router.push("/auth")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <div className="py-4">
      <h2 className="text-2xl font-bold mb-6 text-primary gala-heading">GALA</h2>

      {user ? (
        <>
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
              {user.displayName ? user.displayName[0] : user.email?.[0] || "U"}
            </div>
            <div className="ml-3">
              <p className="font-medium">{user.displayName || "User"}</p>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>
          </div>

          <nav className="space-y-2">
            <Button variant="ghost" className="w-full justify-start" onClick={() => router.push("/listings")}>
              <Home className="mr-2 h-4 w-4" />
              Home
            </Button>

            <Button variant="ghost" className="w-full justify-start" onClick={() => router.push("/profile")}>
              <User className="mr-2 h-4 w-4" />
              Profile
            </Button>

            <Button variant="ghost" className="w-full justify-start" onClick={() => router.push("/wishlists")}>
              <Heart className="mr-2 h-4 w-4" />
              Wishlists
            </Button>

            <Button variant="ghost" className="w-full justify-start" onClick={() => router.push("/messages")}>
              <MessageSquare className="mr-2 h-4 w-4" />
              Messages
            </Button>

            <Separator className="my-4" />

            <Button variant="ghost" className="w-full justify-start" onClick={() => router.push("/host/create")}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Host a Property
            </Button>

            <Button variant="ghost" className="w-full justify-start text-destructive" onClick={handleSignOut}>
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </Button>
          </nav>
        </>
      ) : (
        <div className="space-y-4">
          <p className="text-center">Sign in to access all features</p>
          <Button className="w-full" onClick={() => router.push("/auth")}>
            Sign In
          </Button>
        </div>
      )}
    </div>
  )
}

