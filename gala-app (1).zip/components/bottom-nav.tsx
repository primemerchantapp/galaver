"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Search, Heart, MessageSquare, User } from "lucide-react"
import { cn } from "@/lib/utils"

const GalaCarIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-6 h-6">
    <path
      d="M6 13.5h12M6 13.5a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm12 0a1.5 1.5 0 100 3 1.5 1.5 0 000-3z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M3 11l2-6h14l2 6v7a1 1 0 01-1 1H4a1 1 0 01-1-1v-7zM3 11h18"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path d="M9 3v2M15 3v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
)

export default function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t px-4 py-2 h-[70px]">
      <div className="flex justify-around items-center max-w-lg mx-auto h-full">
        <NavItem
          href="/explore"
          icon={<Search className="w-6 h-6" />}
          label="Explore"
          isActive={pathname === "/explore"}
        />
        <NavItem
          href="/wishlists"
          icon={<Heart className="w-6 h-6" />}
          label="Wishlists"
          isActive={pathname === "/wishlists"}
        />
        <NavItem href="/" icon={<GalaCarIcon />} label="Gala" isActive={pathname === "/"} isMain />
        <NavItem
          href="/messages"
          icon={<MessageSquare className="w-6 h-6" />}
          label="Messages"
          isActive={pathname === "/messages"}
        />
        <NavItem
          href="/profile"
          icon={<User className="w-6 h-6" />}
          label="Profile"
          isActive={pathname === "/profile"}
        />
      </div>
    </nav>
  )
}

interface NavItemProps {
  href: string
  icon: React.ReactNode
  label: string
  isActive?: boolean
  isMain?: boolean
}

function NavItem({ href, icon, label, isActive, isMain }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-all duration-200",
        isActive ? "text-primary" : "text-muted-foreground",
        isMain && !isActive && "text-muted-foreground",
      )}
    >
      <span
        className={cn(
          "relative",
          isActive && "bg-gray-100 rounded-full p-2 shadow-sm",
          isActive ? "scale-125" : "hover:scale-110",
        )}
      >
        {icon}
      </span>
      <span className="text-xs font-medium">{label}</span>
    </Link>
  )
}

