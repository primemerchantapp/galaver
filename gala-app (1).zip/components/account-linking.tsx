"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabase = createClient(supabaseUrl, supabaseAnonKey)

export function AccountLinking() {
  const router = useRouter()
  const { user, signIn } = useAuth()
  const { toast } = useToast()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLinking, setIsLinking] = useState(false)

  const handleAccountLinking = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLinking(true)

    try {
      // 1. Get the current anonymous session
      const { data: anonData, error: anonError } = await supabase.auth.getSession()

      if (anonError || !anonData.session) {
        throw new Error("No anonymous session found")
      }

      // 2. Attempt to update the user with the existing email
      const { error: updateError } = await supabase.auth.updateUser({ email })

      if (updateError) {
        // 3. Handle the error (since the email belongs to an existing user)
        console.log("This email belongs to an existing user. Attempting to sign in...")

        // 4. Sign in to the existing account
        const { data, error: signInError } = await signIn(email, password)

        if (signInError) {
          throw signInError
        }

        if (data.user) {
          // 5. Reassign entities tied to the anonymous user
          await reassignUserData(anonData.session.user.id, data.user.id)

          // 6. Resolve data conflicts
          await resolveDataConflicts(anonData.session.user.id, data.user.id)

          toast({
            title: "Account Linked",
            description: "Your anonymous account has been successfully linked to your existing account.",
          })

          router.push("/profile") // Redirect to profile page or dashboard
        }
      } else {
        // If update was successful, it means this is a new email
        toast({
          title: "Email Added",
          description: "Your email has been successfully added to your account.",
        })

        router.push("/profile") // Redirect to profile page or dashboard
      }
    } catch (error) {
      console.error("Error linking account:", error)
      toast({
        title: "Error",
        description: "Failed to link account. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLinking(false)
    }
  }

  return (
    <form onSubmit={handleAccountLinking} className="space-y-4">
      <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      <Input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <Button type="submit" disabled={isLinking} className="w-full">
        {isLinking ? "Linking Account..." : "Link Account"}
      </Button>
    </form>
  )
}

async function reassignUserData(anonymousUserId: string, existingUserId: string) {
  // Reassign data from various tables
  const tables = ["wishlists", "bookings", "messages"] // Add other relevant tables

  for (const table of tables) {
    const { error } = await supabase.from(table).update({ user_id: existingUserId }).eq("user_id", anonymousUserId)

    if (error) {
      console.error(`Error reassigning data in ${table}:`, error)
    }
  }
}

async function resolveDataConflicts(anonymousUserId: string, existingUserId: string) {
  // Implement your conflict resolution logic here
  // This could involve merging data, keeping the most recent data, or applying custom business logic

  // For example, merging wishlists:
  const { data: anonymousWishlists, error: anonError } = await supabase
    .from("wishlists")
    .select("property_id")
    .eq("user_id", anonymousUserId)

  if (anonError) {
    console.error("Error fetching anonymous wishlists:", anonError)
    return
  }

  for (const item of anonymousWishlists) {
    const { error } = await supabase
      .from("wishlists")
      .insert({ user_id: existingUserId, property_id: item.property_id })
      .onConflict(["user_id", "property_id"])
      .ignore()

    if (error) {
      console.error("Error merging wishlist item:", error)
    }
  }

  // Add similar logic for other data that needs to be merged or resolved
}

