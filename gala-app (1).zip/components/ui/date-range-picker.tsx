"use client"

import { useState } from "react"
import { Calendar } from "lucide-react"
import { DateRange } from "react-date-range"
import { format } from "date-fns"
import { addDays } from "date-fns"

interface DateRangePickerProps {
  selected?: { from: Date; to: Date } | null
  onSelect: (value: { from: Date; to: Date }) => void
  className?: string
}

export const DateRangePicker = ({ selected, onSelect, className }: DateRangePickerProps) => {
  const [state, setState] = useState({
    selection: selected || { startDate: new Date(), endDate: addDays(new Date(), 1) },
  })

  return (
    <div className={className}>
      <DateRange
        state={state}
        onChange={setState}
        format="MM/dd/yyyy"
        rangeColors={["#017cd1"]}
        className="w-full"
        onSelectionChange={({ selection }) => {
          onSelect({ from: selection.startDate, to: selection.endDate })
        }}
      >
        {({ getInputProps, getRootProps, getAriaProps, getMonthProps, getDayProps }) => (
          <div className="relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Select Dates</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {state.selection.startDate &&
                  state.selection.endDate &&
                  `${format(state.selection.startDate, "MM/dd/yyyy")} - ${format(state.selection.endDate, "MM/dd/yyyy")}`}
              </span>
            </div>
          </div>
        )}
      </DateRange>
    </div>
  )
}

