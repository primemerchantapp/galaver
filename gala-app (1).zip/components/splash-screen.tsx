"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function SplashScreen() {
  const router = useRouter()
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      router.push("/listings")
    }, 2000)

    return () => clearTimeout(timer)
  }, [router])

  if (!isVisible) return null

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-primary z-50">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white gala-heading">GALA</h1>
        <p className="text-white mt-2">Discover unique stays in the Philippines</p>
      </div>
    </div>
  )
}

