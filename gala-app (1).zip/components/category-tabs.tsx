import {
  Home,
  Building,
  Building2,
  Hotel,
  Umbrella,
  HomeIcon as House,
  MapIcon as City,
  Mountain,
  Tent,
} from "lucide-react"

const categories = [
  { name: "All", icon: <Home className="w-4 h-4" /> },
  { name: "Hotels", icon: <Hotel className="w-4 h-4" /> },
  { name: "Resorts", icon: <Umbrella className="w-4 h-4" /> },
  { name: "Apartments", icon: <Building className="w-4 h-4" /> },
  { name: "Condominiums", icon: <Building2 className="w-4 h-4" /> },
  { name: "Houses", icon: <House className="w-4 h-4" /> },
  { name: "Townhouses", icon: <City className="w-4 h-4" /> },
  { name: "Recreations", icon: <Mountain className="w-4 h-4" /> },
  { name: "Adventures", icon: <Tent className="w-4 h-4" /> },
  { name: "Cottages", icon: <Home className="w-4 h-4" /> },
  { name: "Others", icon: <Home className="w-4 h-4" /> },
]

interface CategoryTabsProps {
  selectedCategory: string
  onSelectCategory: (category: string) => void
}

export default function CategoryTabs({ selectedCategory, onSelectCategory }: CategoryTabsProps) {
  return (
    <div className="flex overflow-x-auto no-scrollbar px-4 pb-4 gap-2">
      {categories.map(({ name, icon }) => (
        <button
          key={name}
          onClick={() => onSelectCategory(name)}
          className={`
            px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap
            transition-all duration-200 flex items-center gap-2
            ${selectedCategory === name ? "bg-primary text-white" : "bg-muted/50 text-foreground hover:bg-muted"}
          `}
        >
          {icon}
          {name}
        </button>
      ))}
    </div>
  )
}

export { categories }

