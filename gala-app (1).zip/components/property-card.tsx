"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Users, Wifi, ChefHat, Car, MapPin, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Property {
  id: string
  name: string
  location: string
  price_per_night: number
  guests: number
  amenities: string[]
  image: string
  distance?: number
}

interface PropertyCardProps {
  property: Property
  onToggleFavorite: (propertyId: string) => void
  isFavorite: boolean
  mainImage: string
}

export default function PropertyCard({ property, onToggleFavorite, isFavorite, mainImage }: PropertyCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const router = useRouter()

  // Get amenity icon
  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case "wifi":
        return <Wifi className="h-3 w-3" />
      case "kitchen":
        return <ChefHat className="h-3 w-3" />
      case "parking":
        return <Car className="h-3 w-3" />
      default:
        return null
    }
  }

  const handleCardClick = () => {
    router.push(`/property/${property.id}`)
  }

  return (
    <div
      className="bg-white rounded-lg overflow-hidden border shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleCardClick}
    >
      <div className="relative aspect-[4/3]">
        <Image src={mainImage || "/placeholder.svg"} alt={property.name} fill className="object-cover" />
        <Button
          variant="ghost"
          size="icon"
          className={`absolute top-2 right-2 bg-white/80 hover:bg-white ${
            isFavorite ? "text-red-500" : "text-gray-500"
          }`}
          onClick={(e) => {
            e.stopPropagation()
            onToggleFavorite(property.id)
          }}
        >
          <Heart className={`h-5 w-5 ${isFavorite ? "fill-current" : ""}`} />
        </Button>
      </div>
      <div className="p-2 space-y-1">
        <h3 className="font-semibold text-sm line-clamp-1">{property.name}</h3>
        <p className="text-muted-foreground text-xs line-clamp-1">{property.location}</p>

        {property.distance && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            <span>{property.distance.toFixed(1)} km away</span>
          </div>
        )}

        <div className="flex flex-wrap gap-1">
          {property.amenities.slice(0, 3).map((amenity) => (
            <div key={amenity} className="flex items-center gap-1 px-1.5 py-0.5 bg-muted/50 rounded-full text-xs">
              {getAmenityIcon(amenity)}
              <span className="sr-only">{amenity}</span>
            </div>
          ))}
          {property.amenities.length > 3 && (
            <div className="px-1.5 py-0.5 bg-muted/50 rounded-full text-xs">+{property.amenities.length - 3}</div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-baseline gap-0.5">
            <span className="text-primary font-semibold text-sm">₱{property.price_per_night.toLocaleString()}</span>
            <span className="text-muted-foreground text-xs">/night</span>
          </div>

          <div className="flex items-center gap-1 text-muted-foreground text-xs">
            <Users className="h-3 w-3" />
            <span>{property.guests}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

