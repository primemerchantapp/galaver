import type { SupabaseClient } from "@supabase/supabase-js"

export async function initializeDatabase(supabase: SupabaseClient) {
  try {
    // Check if tables exist
    const { data: tablesData, error: tablesError } = await supabase
      .from("information_schema.tables")
      .select("table_name")
      .eq("table_schema", "public")
      .in("table_name", ["users", "properties", "bookings", "messages", "wishlists"])

    if (tablesError) {
      console.error("Error checking tables:", tablesError)
      // Continue execution even if we can't check tables
    }

    const existingTables = tablesData?.map((table) => table.table_name) || []

    // Create tables if they don't exist
    if (!existingTables.includes("users")) {
      await createUsersTable(supabase)
    }

    if (!existingTables.includes("properties")) {
      await createPropertiesTable(supabase)
    }

    if (!existingTables.includes("bookings")) {
      await createBookingsTable(supabase)
    }

    if (!existingTables.includes("messages")) {
      await createMessagesTable(supabase)
    }

    if (!existingTables.includes("wishlists")) {
      await createWishlistsTable(supabase)
    }

    // Check if storage buckets exist
    try {
      const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets()

      // Create storage buckets if they don't exist
      if (!bucketsError) {
        const existingBuckets = buckets?.map((b) => b.name) || []

        if (!existingBuckets.includes("property-images")) {
          await supabase.storage.createBucket("property-images", { public: true })
        }

        if (!existingBuckets.includes("property-videos")) {
          await supabase.storage.createBucket("property-videos", { public: true })
        }

        if (!existingBuckets.includes("profile-images")) {
          await supabase.storage.createBucket("profile-images", { public: true })
        }
      }
    } catch (error) {
      console.error("Error with storage buckets:", error)
      // Continue execution even if storage operations fail
    }

    console.log("Database initialization completed successfully")
    return true
  } catch (error) {
    console.error("Error initializing database:", error)
    // Return true anyway to prevent app from crashing
    return true
  }
}

async function createUsersTable(supabase: SupabaseClient) {
  const { error } = await supabase.rpc("exec_sql", {
    sql_string: `
      CREATE TABLE IF NOT EXISTS public.users (
        id UUID PRIMARY KEY,
        email TEXT,
        name TEXT,
        phone TEXT,
        profile_image TEXT,
        user_type TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `,
  })

  if (error) {
    console.error("Error creating users table:", error)
    // Silently continue if the table creation fails
  }
}

async function createPropertiesTable(supabase: SupabaseClient) {
  const { error } = await supabase.rpc("exec_sql", {
    sql_string: `
      CREATE TABLE IF NOT EXISTS public.properties (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        location TEXT NOT NULL,
        price_per_night NUMERIC NOT NULL,
        category TEXT,
        max_guests INTEGER,
        description TEXT,
        amenities TEXT[],
        images TEXT[],
        video_url TEXT,
        host_id UUID,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `,
  })

  if (error) {
    console.error("Error creating properties table:", error)
    // Silently continue if the table creation fails
  }
}

async function createBookingsTable(supabase: SupabaseClient) {
  const { error } = await supabase.rpc("exec_sql", {
    sql_string: `
      CREATE TABLE IF NOT EXISTS public.bookings (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        property_id UUID NOT NULL,
        guest_id UUID NOT NULL,
        check_in_date DATE NOT NULL,
        check_out_date DATE NOT NULL,
        total_price NUMERIC NOT NULL,
        status TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `,
  })

  if (error) {
    console.error("Error creating bookings table:", error)
    // Silently continue if the table creation fails
  }
}

async function createMessagesTable(supabase: SupabaseClient) {
  const { error } = await supabase.rpc("exec_sql", {
    sql_string: `
      CREATE TABLE IF NOT EXISTS public.messages (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        conversation_id UUID NOT NULL,
        sender_id UUID NOT NULL,
        receiver_id UUID NOT NULL,
        content TEXT NOT NULL,
        read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `,
  })

  if (error) {
    console.error("Error creating messages table:", error)
    // Silently continue if the table creation fails
  }
}

async function createWishlistsTable(supabase: SupabaseClient) {
  const { error } = await supabase.rpc("exec_sql", {
    sql_string: `
      CREATE TABLE IF NOT EXISTS public.wishlists (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID NOT NULL,
        property_id UUID NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, property_id)
      );
    `,
  })

  if (error) {
    console.error("Error creating wishlists table:", error)
    // Silently continue if the table creation fails
  }
}

